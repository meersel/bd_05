+++
title = "Contact"
type = "contact"
netlify = false
emailservice = "formspree.io/example@email.com"
contactname = "Your name"
contactemail = "Your Email"
contactsubject = "Subject"
contactmessage = "Your Message"
contactlang = "pl"
contactanswertime = 24
+++
