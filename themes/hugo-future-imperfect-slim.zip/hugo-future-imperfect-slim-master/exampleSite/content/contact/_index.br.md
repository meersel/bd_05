+++
title = "Contato"
type = "contact"
netlify = false
emailservice = "formspree.io/example@email.com"
contactname = "Seu nome"
contactemail = "Seu Email"
contactsubject = "Assunto"
contactmessage = "Sua menssagem"
contactlang = "br"
contactanswertime = 24
+++
